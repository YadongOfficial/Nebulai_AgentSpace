# Nebulai Agent System (NPM Version)

This is a multi-agent system using Node.js and Express without Docker. Each agent runs on a separate port and is orchestrated by a Root Agent.

## Agents
- Agent A: Tag 1 - Port 5001
- Agent C: Tag 1, 2 - Port 5002
- Agent E: Tag 4 - Port 5003
- Root Agent: Dispatcher - Port 5000

## Run all agents
```bash
npm install
npm run start:all
```

## Test dispatch
```bash
curl -X POST http://localhost:5000/dispatch -H "Content-Type: application/json" -d '{"tags": [1, 4], "task": "Analyze dataset"}'
```