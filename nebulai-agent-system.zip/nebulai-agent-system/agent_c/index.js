const express = require('express');
const app = express();
app.use(express.json());

app.post('/process', (req, res) => {
  const { task } = req.body;
  res.json({ agent: 'Agent C', result: `Processed C: ${task}` });
});

app.listen(5002, () => console.log('Agent C running on port 5002'));