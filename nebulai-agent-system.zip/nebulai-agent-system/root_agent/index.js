const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

const AGENTS = [
  { name: "Agent A", tags: [1], url: "http://localhost:5001/process" },
  { name: "Agent C", tags: [1, 2], url: "http://localhost:5002/process" },
  { name: "Agent E", tags: [4], url: "http://localhost:5003/process" }
];

app.post('/dispatch', async (req, res) => {
  const { tags, task } = req.body;
  const results = [];

  for (const agent of AGENTS) {
    const intersect = agent.tags.filter(t => tags.includes(t));
    if (intersect.length > 0) {
      try {
        const response = await axios.post(agent.url, { task });
        results.push(response.data);
      } catch (error) {
        results.push({ agent: agent.name, error: error.message });
      }
    }
  }

  res.json({ results });
});

app.listen(5000, () => console.log('Root Agent running on port 5000'));