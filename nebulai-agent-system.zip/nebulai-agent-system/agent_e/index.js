const express = require('express');
const app = express();
app.use(express.json());

app.post('/process', (req, res) => {
  const { task } = req.body;
  res.json({ agent: 'Agent E', result: `Processed E: ${task}` });
});

app.listen(5003, () => console.log('Agent E running on port 5003'));